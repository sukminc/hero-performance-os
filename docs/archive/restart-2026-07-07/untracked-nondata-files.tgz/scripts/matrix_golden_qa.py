#!/usr/bin/env python3
"""Generate a deterministic Matrix golden QA packet for Hero review."""

from __future__ import annotations

import json
import sys
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from app.api.hand_matrix import _fetch_observations, _position_bucket, get_hand_matrix_payload
from core.storage.sqlite import get_sqlite_connection

PLAYER_ID = "4c9d1e29-1f6b-4e5f-92da-111111111111"
GOLDEN_HANDS = ["99", "A5s", "KJo", "AQo", "AKo", "83o"]
REPORT_PATH = REPO_ROOT / "reports/00_foundation/128-matrix-golden-qa-and-trace-report.md"


def fmt(value: Any, suffix: str = "") -> str:
    if value is None or value == "":
        return "n/a"
    return f"{value}{suffix}"


def count_label(count: Any, noun: str) -> str:
    numeric = int(count or 0)
    if numeric == 1 and noun.endswith("s"):
        return f"{numeric} {noun[:-1]}"
    return f"{numeric} {noun}"


def trace_hand(hand_id: str) -> dict[str, Any]:
    with get_sqlite_connection() as conn:
        row = conn.execute(
            """
            SELECT
                hands.id,
                hands.effective_stack_bb,
                hands.result_summary,
                hands.raw_payload,
                sessions.started_at,
                sessions.session_metadata
            FROM hands
            JOIN sessions ON sessions.id = hands.session_id
            WHERE hands.id = ?
            """,
            (hand_id,),
        ).fetchone()
    if not row:
        return {"hand_id": hand_id, "missing": True}

    raw_payload = json.loads(row["raw_payload"] or "{}")
    result_summary = json.loads(row["result_summary"] or "{}")
    block = raw_payload.get("block") or []
    preflop_lines: list[str] = []
    in_preflop = False
    for line in block:
        if line == "*** HOLE CARDS ***":
            in_preflop = True
            continue
        if in_preflop and line.startswith("*** FLOP ***"):
            break
        if not in_preflop or ":" not in line:
            continue
        if (
            "Hero:" in line
            or " raises " in line
            or " calls " in line
            or " folds" in line
            or " checks" in line
        ):
            preflop_lines.append(line)

    return {
        "hand_id": hand_id,
        "started_at": row["started_at"],
        "stack_bb": row["effective_stack_bb"],
        "hero_summary": result_summary.get("hero_summary"),
        "hero_actions": result_summary.get("hero_actions") or [],
        "preflop_lines": preflop_lines,
    }


def line_context(row: dict[str, Any]) -> str:
    pieces: list[str] = []
    if row.get("avg_open_size_bb") is not None:
        pieces.append(f"faced avg {fmt(row.get('avg_open_size_bb'), 'bb')}")
    position_mix = row.get("position_mix") or {}
    if len(position_mix) > 1:
        top = sorted(position_mix.items(), key=lambda item: (-int(item[1]), item[0]))[:3]
        pieces.append(" / ".join(f"{position} {count}" for position, count in top))
    return " · ".join(pieces)


def render_line_table(rows: list[dict[str, Any]], limit: int = 10) -> list[str]:
    output = [
        "| Line | Count | Hero size | Actual BB | Stack | Context |",
        "| --- | ---: | ---: | ---: | ---: | --- |",
    ]
    for row in rows[:limit]:
        line = f"{row.get('position_bucket_label')} · {row.get('line_label')}"
        output.append(
            "| "
            + " | ".join(
                [
                    line,
                    count_label(row.get("count"), "spots"),
                    fmt(row.get("avg_first_action_size_bb"), "bb"),
                    fmt(row.get("avg_bb_per_hand"), "bb"),
                    fmt(row.get("avg_stack_realization_pct"), "%"),
                    line_context(row),
                ]
            )
            + " |"
        )
    return output


def important_loss_lines(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    candidates = [
        row
        for row in rows
        if row.get("performance_scored")
        and (row.get("count") or 0) >= 2
        and (
            float(row.get("avg_stack_realization_pct") or 0) <= -5
            or float(row.get("avg_bb_per_hand") or 0) <= -1
        )
    ]
    return sorted(
        candidates,
        key=lambda row: (
            0 if (row.get("sample_band") != "tiny" and (row.get("count") or 0) >= 3) else 1,
            float(row.get("avg_stack_realization_pct") or row.get("avg_bb_per_hand") or 0),
            -int(row.get("count") or 0),
        ),
    )


def stable_lines(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    stable = [row for row in rows if row.get("sample_band") != "tiny" and (row.get("count") or 0) >= 2]
    return stable if len(stable) >= 3 else rows


def review_prompt_for_hand(hand: str) -> str:
    prompts = {
        "99": "Does the losing evidence concentrate in 25-35bb high-pressure commitment, or is the whole hand class overplayed?",
        "A5s": "Are the losing rows true 3bet-bluff selection mistakes, or one-off postflop/all-in outcomes?",
        "KJo": "Does the data support keeping KJo as a selective 3bet-bluff candidate while avoiding passive large-pressure calls?",
        "AQo": "Are repeated 3bet-folds disciplined folds versus tight 4bet ranges, or is AQo being turned into a bluff too often?",
        "AKo": "Is the AKo 3bet-fold explained by ICM/satellite/field context, or should it be a golden review hand?",
        "83o": "Does low-participation neutralization keep trash hands out of the core Matrix signal?",
    }
    return prompts.get(hand, "Does this hand read match Hero's lived strategic experience?")


def classify_three_bet_fold(hand_class: str) -> str:
    natural = {"A5s", "A4s", "A3s", "K5s", "QTs", "Q9s", "87s"}
    mixed = {"KJo", "KQo", "ATo", "A8s"}
    review = {"AQo", "AKo"}
    weak_offsuit = {"A8o", "A6o", "K9o"}
    if hand_class in natural:
        return "Natural bluff-candidate fold"
    if hand_class in mixed:
        return "Mixed blocker/value-bluff boundary"
    if hand_class in review:
        return "Priority review, not automatic solver-aligned"
    if hand_class in weak_offsuit:
        return "Loose blocker bluff candidate; watch frequency"
    return "One-off review"


def three_bet_fold_section() -> list[str]:
    observations = _fetch_observations(PLAYER_ID, "all", "all", "all", "all", 2)
    three_bets = [row for row in observations if row.preflop_entry_type == "three_bet" and row.hero_3bet_size_bb is not None]
    faced_four_bet = [row for row in three_bets if row.faced_4bet_after_3bet]
    folded = [row for row in faced_four_bet if row.folded_to_4bet_after_3bet]

    lines = [
        "## 3bet-Fold Review",
        "",
        f"- Clean 3bet rows: `{len(three_bets)}`",
        f"- Faced 4bet after 3bet: `{len(faced_four_bet)}`",
        f"- Folded to 4bet: `{len(folded)}`",
        f"- Fold rate after facing 4bet: `{round(len(folded) / len(faced_four_bet) * 100, 1) if faced_four_bet else 0}%`",
        "",
        "| Hand | Count | Buckets | Proxy read |",
        "| --- | ---: | --- | --- |",
    ]

    by_hand: dict[str, list[Any]] = {}
    for row in folded:
        by_hand.setdefault(row.hand_class, []).append(row)
    for hand, items in sorted(by_hand.items(), key=lambda item: (-len(item[1]), item[0])):
        buckets = Counter(_position_bucket(row.position)[1] for row in items)
        bucket_text = ", ".join(f"{bucket} {count}" for bucket, count in buckets.most_common())
        lines.append(f"| {hand} | {len(items)} | {bucket_text} | {classify_three_bet_fold(hand)} |")

    lines.extend(
        [
            "",
            "### Priority Raw Trace",
            "",
            "These are not proof of mistakes; they are the highest-leverage tomorrow-review candidates.",
            "",
        ]
    )
    priority = [row for row in folded if row.hand_class in {"AQo", "AKo", "A5s", "KJo", "KQo", "ATo"}]
    priority = sorted(priority, key=lambda row: (row.hand_class, row.position, row.started_at or ""))[:12]
    for row in priority:
        trace = trace_hand(row.hand_id)
        lines.extend(
            [
                f"- `{row.hand_class}` `{_position_bucket(row.position)[1]}` `{row.position}` "
                f"stack `{fmt(row.stack_bb, 'bb')}` open `{fmt(row.open_size_bb, 'bb')}` "
                f"3bet `{fmt(row.hero_3bet_size_bb, 'bb')}` -> folded to 4bet",
                f"  - hand: `{row.hand_id}`",
                f"  - summary: {trace.get('hero_summary')}",
            ]
        )
    return lines


def golden_hand_section(hand: str, payload: dict[str, Any]) -> list[str]:
    cell = (payload.get("matrix_cells") or {}).get(hand) or {}
    line_rows = cell.get("preflop_line_breakdown") or []
    stable = stable_lines(line_rows)
    losses = important_loss_lines(line_rows)
    read = cell.get("english_read") or {}

    lines = [
        f"## {hand}",
        "",
        "| Metric | Value |",
        "| --- | ---: |",
        f"| Dealt | {cell.get('dealt_count', 0)} |",
        f"| Played | {cell.get('played_count', 0)} |",
        f"| No entry | {cell.get('non_played_count', 0)} |",
        f"| Participation | {fmt(cell.get('participation_rate_pct'), '%')} |",
        f"| Avg BB / played hand | {fmt(cell.get('avg_bb_per_hand'), 'bb')} |",
        f"| Avg stack realization | {fmt(cell.get('avg_stack_realization_pct'), '%')} |",
        f"| Low participation neutralized | {cell.get('low_participation')} |",
        "",
        f"**Current read:** {read.get('one_liner') or read.get('headline') or 'No deterministic read yet.'}",
        "",
        "### Primary Stable Lines",
        "",
        *render_line_table(stable, limit=8),
        "",
        "### Important Losing Lines",
        "",
    ]
    if losses:
        lines.extend(render_line_table(losses, limit=6))
    else:
        lines.append("No repeated losing preflop-line row met the QA threshold.")

    lines.extend(["", "### Raw Trace Examples", ""])
    example_ids: list[str] = []
    for row in (losses or stable)[:3]:
        for example in row.get("examples") or []:
            hand_id = example.get("hand_id")
            if hand_id and hand_id not in example_ids:
                example_ids.append(hand_id)
            if len(example_ids) >= 3:
                break
        if len(example_ids) >= 3:
            break
    if not example_ids:
        lines.append("No raw examples available from current Matrix payload.")
    for hand_id in example_ids:
        trace = trace_hand(hand_id)
        lines.extend(
            [
                f"- `{hand_id}`",
                f"  - started: `{trace.get('started_at')}` · stack: `{fmt(trace.get('stack_bb'), 'bb')}`",
                f"  - summary: {trace.get('hero_summary')}",
                f"  - hero actions: {' / '.join(trace.get('hero_actions') or [])}",
                f"  - preflop trace: {' / '.join((trace.get('preflop_lines') or [])[:8])}",
            ]
        )

    lines.extend(
        [
            "",
            "### Tomorrow Review Question",
            "",
            f"- {review_prompt_for_hand(hand)}",
            "",
        ]
    )
    return lines


def main() -> None:
    payload = get_hand_matrix_payload(player_id=PLAYER_ID, window="all", selected_hand="66")
    sizing = payload.get("preflop_sizing_summary") or {}
    aof = payload.get("preflop_aof_summary") or {}

    lines = [
        "# Matrix Golden QA and Trace Report",
        "",
        f"Generated: `{datetime.now(UTC).isoformat(timespec='seconds')}`",
        f"Player: `{PLAYER_ID}`",
        "",
        "## TASK",
        "",
        "Prepare objective QA material for tomorrow's product review without requiring live operator decisions.",
        "",
        "## WHAT I CHECKED",
        "",
        "- Matrix cell calculation policy: played pots drive performance; dealt folds remain exposure context.",
        "- Golden hand classes: `99`, `A5s`, `KJo`, `AQo`, `AKo`, `83o`.",
        "- Preflop line breakdowns, important losing lines, low-participation behavior, and raw hand traceability.",
        "- 3bet-fold candidates versus a solver-principle proxy, not an exact solver node.",
        "",
        "## Baseline Consistency Snapshot",
        "",
        f"- Total hands: `{sizing.get('total_hands')}`",
        f"- Open baseline: avg `{fmt(sizing.get('avg_standard_open_size_bb'), 'x')}`, "
        f"mode `{fmt(sizing.get('open_size_mode_bb'), 'x')}`, near-2x `{fmt(sizing.get('two_x_open_rate_pct'), '%')}`",
        f"- HU 3bet vs 2x baseline: avg `{fmt(sizing.get('avg_3bet_vs_2x_single_bb'), 'x')}`, "
        f"mode `{fmt(sizing.get('mode_3bet_vs_2x_single_bb'), 'x')}`, clean spots `{sizing.get('three_bet_vs_2x_single_count')}`",
        f"- AOF baseline: avg `{fmt((aof.get('overall') or {}).get('avg_stack_bb'), 'bb')}`, "
        f"median `{fmt((aof.get('overall') or {}).get('median_stack_bb'), 'bb')}`, jams `{(aof.get('overall') or {}).get('count')}`",
        "",
        "## QA Interpretation Guardrails",
        "",
        "- This report uses actual final hand result after a preflop line; it is not solver EV or all-in adjusted EV.",
        "- One-hand postflop stack-offs are examples, not baseline conclusions.",
        "- Solver comparison here means blocker/realization/position/stack proxy review only.",
        "",
    ]

    for hand in GOLDEN_HANDS:
        lines.extend(golden_hand_section(hand, payload))

    lines.extend(three_bet_fold_section())

    lines.extend(
        [
            "",
            "## RISKS / OPEN QUESTIONS",
            "",
            "- `Call vs open` still needs pressure buckets: normal open, large open, and jam/all-in pressure.",
            "- `Hero size` / `First size` language still needs one final UX decision because call rows and raise rows mean different things.",
            "- 99/AQo/AKo need human strategy review before turning any finding into product copy.",
            "",
            "## OUT OF SCOPE",
            "",
            "- No code behavior changed by this report generation.",
            "- No solver import or exact GTO lookup.",
            "- No paid-user UI changes.",
            "",
            "## TEST / VALIDATION",
            "",
            "- Generated from current Matrix backend payload and local Hero SQLite truth.",
            "- Raw hand ids in the report are queryable in local storage.",
            "- Validation commands for this task: `python3 scripts/matrix_golden_qa.py`, `python3 tests/matrix_position_situation_tests.py`, `python3 tests/matrix_quiz_tests.py`, `python3 tests/service_boundary_tests.py`.",
            "",
            "## RECOMMENDED NEXT STEP",
            "",
            "Tomorrow, review only these decisions:",
            "",
            "1. Does the 99 high-pressure interpretation match Hero's lived baseline shift?",
            "2. Does KJo read as a selective 3bet-bluff hand rather than a range cut?",
            "3. Are AQo/AKo 3bet-folds disciplined exploit folds or red-flag weak folds?",
            "4. Should product copy say `Actual BB` or `Final result`?",
            "5. Which golden hand should become the first public demo story?",
            "",
        ]
    )

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(REPORT_PATH)


if __name__ == "__main__":
    main()
