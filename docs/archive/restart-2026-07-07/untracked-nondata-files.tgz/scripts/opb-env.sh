#!/usr/bin/env bash

# Source this file before local OPB development on a fresh machine:
#   source scripts/opb-env.sh
#
# It keeps repo-local tools ahead of the macOS system defaults so Python 3.12,
# Node, npm, and Next use versions that can run the Matrix stack.

if [ -n "${BASH_SOURCE[0]:-}" ]; then
  OPB_ENV_SCRIPT="${BASH_SOURCE[0]}"
elif [ -n "${(%):-%x}" ]; then
  OPB_ENV_SCRIPT="${(%):-%x}"
else
  OPB_ENV_SCRIPT="$0"
fi

OPB_REPO_ROOT="$(cd "$(dirname "$OPB_ENV_SCRIPT")/.." && pwd)"
OPB_LOCAL_NODE="$OPB_REPO_ROOT/.local/node-v22.15.0-darwin-arm64/bin"
OPB_CODEX_PYTHON="/Users/chrisyoon/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin"

export PATH="$OPB_LOCAL_NODE:$OPB_CODEX_PYTHON:$PATH"
export PYTHONPATH="$OPB_REPO_ROOT${PYTHONPATH:+:$PYTHONPATH}"
export OPB_SQLITE_DB_PATH="${OPB_SQLITE_DB_PATH:-$OPB_REPO_ROOT/data/hero_v2.sqlite3}"
export OPB_UPLOAD_TMP_DIR="${OPB_UPLOAD_TMP_DIR:-$OPB_REPO_ROOT/data/tmp_uploads_public}"
export NEXT_TELEMETRY_DISABLED=1

echo "OPB env ready"
echo "repo: $OPB_REPO_ROOT"
echo "python: $(command -v python3) ($(python3 --version 2>&1))"
echo "node: $(command -v node) ($(node --version 2>&1))"
echo "npm: $(command -v npm) ($(npm --version 2>&1))"
