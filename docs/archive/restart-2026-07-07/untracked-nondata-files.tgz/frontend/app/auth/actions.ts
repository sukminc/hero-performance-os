"use server";

import { headers } from "next/headers";
import { createSupabaseServerClient } from "@/lib/auth/supabase";

export type MagicLinkState = {
  ok: boolean;
  message: string;
  email?: string;
};

function normalizeEmail(formData: FormData) {
  const value = formData.get("email");
  return typeof value === "string" ? value.trim().toLowerCase() : "";
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export async function sendMagicLink(_prevState: MagicLinkState | null, formData: FormData): Promise<MagicLinkState> {
  const email = normalizeEmail(formData);
  const next = typeof formData.get("next") === "string" ? String(formData.get("next")) : "/app/matrix";

  if (!isValidEmail(email)) {
    return { ok: false, message: "Enter a valid email address." };
  }

  const client = await createSupabaseServerClient();
  if (!client) {
    return {
      ok: false,
      message: "Magic-link access is not public on this deployment yet. Request founding access for manual setup.",
      email,
    };
  }

  const headerStore = await headers();
  const origin =
    headerStore.get("origin") ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.VERCEL_PROJECT_PRODUCTION_URL ||
    "http://localhost:3000";
  const siteOrigin = origin.startsWith("http") ? origin : `https://${origin}`;
  const redirectUrl = new URL("/auth/callback", siteOrigin);
  redirectUrl.searchParams.set("next", next);

  const { error } = await client.auth.signInWithOtp({
    email,
    options: {
      emailRedirectTo: redirectUrl.toString(),
      shouldCreateUser: true,
    },
  });

  if (error) {
    return { ok: false, message: error.message, email };
  }

  return {
    ok: true,
    email,
    message: "Magic link sent. Check your email, then continue to checkout to unlock your Matrix.",
  };
}
