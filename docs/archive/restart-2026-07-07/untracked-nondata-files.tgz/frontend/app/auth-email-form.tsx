"use client";

import { useActionState } from "react";
import { sendMagicLink, type MagicLinkState } from "./auth/actions";

type AuthEmailFormProps = {
  ctaLabel?: string;
  next?: string;
};

const initialState: MagicLinkState = {
  ok: false,
  message: "",
};

export function AuthEmailForm({ ctaLabel = "Send Magic Link", next = "/app/matrix" }: AuthEmailFormProps) {
  const [state, formAction, isPending] = useActionState(sendMagicLink, initialState);

  if (state.ok) {
    return (
      <div className="success-card paid-signup-success">
        <p className="eyebrow">Check Your Email</p>
        <h3>Magic link sent.</h3>
        <p className="subtle">{state.message}</p>
        {state.email ? <p className="paid-email-confirm">{state.email}</p> : null}
      </div>
    );
  }

  return (
    <form className="paid-signup-form" action={formAction}>
      <input type="hidden" name="next" value={next} />
      <label>
        Email
        <input name="email" required type="email" placeholder="you@example.com" autoComplete="email" />
      </label>
      {state.message ? <p className="form-error">{state.message}</p> : null}
      <button className="cta button-reset" type="submit" disabled={isPending}>
        {isPending ? "Sending..." : ctaLabel}
      </button>
    </form>
  );
}
