const schemes = [
  {
    key: "clean-felt",
    label: "A",
    name: "Clean Felt",
    note: "Poker-native, brighter felt, still premium.",
    className: "scheme-clean-felt",
  },
  {
    key: "performance-lab",
    label: "B",
    name: "Performance Lab",
    note: "Crisp SaaS analytics, less casino, more data product.",
    className: "scheme-performance-lab",
  },
  {
    key: "premium-warm",
    label: "C",
    name: "Premium Warm",
    note: "Founding member energy, warmer and more editorial.",
    className: "scheme-premium-warm",
  },
];

const demoHands = ["AA", "AKs", "AQs", "KQs", "QJs", "TT", "A5s", "KQo", "66", "A9o", "T8s", "55"];

export default function StylePreviewPage() {
  return (
    <main className="style-preview-page">
      <header className="style-preview-header">
        <p className="eyebrow">Color Direction</p>
        <h1>Pick the landing page mood.</h1>
        <p>
          These are quick visual mockups only. After you choose one, I will apply that direction to the real landing
          CSS.
        </p>
      </header>

      <section className="style-scheme-grid">
        {schemes.map((scheme) => (
          <article className={`style-scheme-card ${scheme.className}`} key={scheme.key}>
            <div className="style-scheme-top">
              <span>{scheme.label}</span>
              <div>
                <strong>{scheme.name}</strong>
                <p>{scheme.note}</p>
              </div>
            </div>

            <div className="style-scheme-hero">
              <div>
                <span className="style-offer">Founding 50 - $29 first 90 days</span>
                <h2>Upload your hand history. See how you actually play.</h2>
                <p>Personal Matrix, rolling 90-day baseline, and a short leak watchlist.</p>
                <button type="button">Get My Matrix</button>
              </div>

              <div className="style-mini-matrix">
                {demoHands.map((hand, index) => (
                  <span className={index % 4 === 0 ? "value" : index % 5 === 0 ? "danger" : "watch"} key={hand}>
                    {hand}
                  </span>
                ))}
              </div>
            </div>

            <div className="style-scheme-footer">
              <span>Track change over time</span>
              <span>Preserve GG history</span>
              <span>Monthly leak watchlist</span>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}
