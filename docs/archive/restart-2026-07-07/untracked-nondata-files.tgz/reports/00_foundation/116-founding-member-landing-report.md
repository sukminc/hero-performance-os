# TASK
Create the local founding-member landing page plan and first implementation for the OPB Matrix MVP.

# WHAT I CHANGED
- Replaced the outdated `/` landing page with a Founding 50 offer page:
  - headline: `Upload your hand history. See how you actually play.`
  - primary CTA: `Get My Matrix`
  - secondary CTA: `View Founding Offer`
  - demo-only 13x13 Matrix preview
  - Founding 90-Day Baseline Pass offer: `$29 first 90 days`, first 50 players, then `$19/mo`
  - retention messaging around 7 / 30 / 90 day tracking, GG hand-history preservation, and monthly leak watchlists
  - post-session-only / not-a-solver positioning
- Updated `/signup` toward the founding access flow:
  - "Create an account to upload your first hand history"
  - founding access request copy
  - GG hand-history target, not Ontario-only
- Updated `/login` copy to return users to the Matrix workspace.
- Added unpaid preview behavior to `/app/matrix` when a user is unmapped or has no parsed hands:
  - sample Matrix cards only
  - locked premium sections
  - no Hero data fallback
- Updated `docs/active_task.md` with the landing task brief.

# ARCHITECTURE IMPACT
- Public acquisition now points to the Matrix MVP instead of an early demo request.
- The user-facing story is now upload -> personal Matrix -> rolling baseline -> recurring review value.
- Hero's real hand data remains excluded from marketing and unpaid preview surfaces.

# DECISIONS MADE
- Target wording is `GG Poker hand histories`, not Ontario-only.
- The first paid offer is a founding pass, not a one-time report.
- Current public pricing message is `$29 for first 90 days`, then `$19/mo`.
- Future features are shown as "Shipping Next" rather than paid tiers that are not implemented yet.
- Signup remains an access request until magic-link auth and Stripe checkout are wired in a later task.

# RISKS / OPEN QUESTIONS
- Real magic-link auth and checkout are not implemented yet.
- The access form still uses the existing demo-application backend path and should be replaced by production auth/checkout before launch traffic.
- Browser screenshot capture through Playwright CLI hung on the dev server load event; in-app Browser verification worked after restarting the local dev server.
- The landing visual should still be reviewed by the user before production deployment.

# OUT OF SCOPE
- Stripe checkout.
- Supabase magic-link implementation.
- Production deployment.
- Backend upload service deployment.
- Postgres migration.
- Real member limit enforcement for the first 50 users.

# TEST / VALIDATION
- `npm run build` passed.
- Local dev server verified at `http://localhost:3000/`.
- In-app Browser checked the landing page and confirmed:
  - headline present
  - `$29` offer present
  - `Get My Matrix` CTA present
- Browser visual QA caught an overly low hero layout; CSS was adjusted so the hero content appears in the first viewport.
- `curl` verified `/` and `/signup` HTML render after restarting the dev server.

# RECOMMENDED NEXT STEP
Review the local landing visually, then wire the actual founding flow: magic-link auth, Stripe checkout for `$29 first 90 days`, and a paid/unpaid account state that routes paid users to `/app/upload`.
