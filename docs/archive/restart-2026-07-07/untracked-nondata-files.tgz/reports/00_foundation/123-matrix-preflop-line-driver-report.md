# TASK
Convert Matrix pinned detail drivers from raw position/situation rows toward position-bucket + Hero preflop-line rows.

# WHAT I CHANGED
- Added deterministic `preflop_line_key` / `preflop_line_label` fields to `HandObservation`.
- Added backend preflop-line feature extraction for combo decisions:
  - `Open -> fold vs 3bet`
  - `Open -> flat 3bet`
  - `Open -> 4bet`
  - `Open -> 4bet jam`
  - `3bet -> fold vs 4bet`
  - `3bet -> flat 4bet`
  - `3bet -> 5bet`
  - `3bet -> 5bet jam`
- Added `preflop_line_breakdown` to Matrix cells and selected-hand detail.
- Kept raw fold exposure out of `preflop_line_breakdown`; folds remain in the dedicated fold-exposure section.
- Grouped pinned detail rows by position bucket:
  - Early
  - Mid
  - CO
  - BTN
  - SB
  - BB
- Updated `/operator/matrix` pinned detail to prefer `preflop_line_breakdown` and show `Position bucket + preflop line`.
- Kept `position_situation_breakdown` in the payload as a compatibility fallback.
- Updated `DECISIONS_LOG.md` with the new product truth.

# ARCHITECTURE IMPACT
- The Matrix now has a clearer preflop-specific derived layer for actual-result interpretation.
- This keeps raw hand/session truth unchanged and adds a deterministic derived grouping layer.
- The UI is now closer to the MVP business question: which repeated Hero preflop line is producing the result?

# DECISIONS MADE
- Use buckets instead of exact positions as the primary pinned-detail lens.
- Use combo line labels when the parser can deterministically see the later preflop response.
- Show first Hero action size as `bb` in this table to avoid repeated `x` ambiguity.
- Preserve the old position/situation rows for existing readers and fallback behavior.

# RISKS / OPEN QUESTIONS
- GG text can encode some all-in / raise language differently; combo extraction may need more fixtures from real packets.
- Terminal line size is not fully separated from first-action size yet. A future slice can add `terminal_preflop_size_bb`.
- Some postflop actual results can still dominate a preflop line row because this is actual-result baseline, not all-in adjusted EV.

# OUT OF SCOPE
- No solver comparison.
- No all-in adjusted EV calculation.
- No new canonical database schema.
- No consumer-facing upload or paid gating work in this slice.

# TEST / VALIDATION
- `python3 tests/matrix_position_situation_tests.py`
- `python3 tests/matrix_quiz_tests.py`
- `python3 tests/service_boundary_tests.py`
- `npm run build`
- `npm run qa:matrix:render`
- Inspected generated screenshots:
  - `tmp/qa/matrix-render-desktop.png`
  - `tmp/qa/matrix-render-desktop-full.png`
  - `tmp/qa/matrix-render-mobile-full.png`

# RECOMMENDED NEXT STEP
Add a few real GG hand fixtures for:
- open then fold versus 3bet
- open then 4bet jam
- 3bet then fold versus 4bet
- 3bet then 5bet jam
- call versus large all-in

Those fixtures will make the new preflop-line layer more trustworthy before exposing it as paid-user copy.
