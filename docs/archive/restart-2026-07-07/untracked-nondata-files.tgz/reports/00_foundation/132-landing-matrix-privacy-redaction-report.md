# TASK
Redact private baseline sample size and exact BB/result metrics from the public landing Matrix preview.

# WHAT I CHANGED
- Removed the exact `27,280` hand count from the public landing copy.
- Removed exact BB/result and play-rate labels from the Matrix preview cells.
- Removed the embedded aggregate BB/sample payload from the public page component.
- Replaced the public readout with privacy-safe language:
  - private results stay private
  - exact hand counts, BB results, and personal evidence stay behind access
- Kept a Matrix-shaped preview with qualitative tones only.
- Deployed the updated frontend to Vercel production.
- Re-pointed `onepercentbetter.poker` and `www.onepercentbetter.poker` to the new deployment.

# ARCHITECTURE IMPACT
- Improves public privacy posture.
- Public landing no longer exposes exact private sample size or exact hand-class result metrics.
- No backend, parser, Matrix truth, or auth behavior changed.

# DECISIONS MADE
- Treated exact public sample size and BB-per-hand numbers as private.
- Kept the preview useful by showing structure and tone without exact evidence.

# RISKS / OPEN QUESTIONS
- The preview still uses qualitative tone classes; before a broader public launch, decide whether even qualitative personal baseline coloring should be synthetic or generated from a sanitized demo account.

# OUT OF SCOPE
- Building a sanitized public preview fixture.
- Supabase/Stripe setup.
- Git commit/push.

# TEST / VALIDATION
- Searched `frontend/app/page.tsx` for exact `27,280`, `27280`, BB-result labels, play-rate labels, and old aggregate copy.
- `npm run build` passed.
- `vercel deploy --prod -y` completed successfully.
- `vercel alias set` completed for both live poker domains.

# RECOMMENDED NEXT STEP
Replace the remaining qualitative tone preview with a dedicated non-Hero demo fixture when there is time after the interview.
