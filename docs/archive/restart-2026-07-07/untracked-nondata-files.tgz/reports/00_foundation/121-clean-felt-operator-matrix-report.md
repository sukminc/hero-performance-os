# TASK

Bring `/operator/matrix` into the same Clean Felt visual direction as the landing page.

# WHAT I CHANGED

- Added a scoped Clean Felt theme for `.matrix-shell`.
- Converted Matrix cards, sizing summary, AOF, runout guardrail, correction candidates, full 13x13 Matrix, and pinned detail cards from dark panels to light product panels.
- Preserved the Matrix signal colors:
  - green for positive/value,
  - coral/red for negative/leak,
  - yellow for watch/caution,
  - pale neutral for low-participation or baseline cells.
- Changed pinned detail layout so a single pinned card uses the full row instead of leaving a dark empty column.
- Improved runout guardrail text contrast after screenshot inspection.

# ARCHITECTURE IMPACT

- Frontend CSS-only visual change.
- No Matrix payload, parser, backend truth, upload, auth, or payment logic changed.
- The MVP proof surface now visually matches the public landing direction.

# DECISIONS MADE

- The paid MVP surface should feel like the same product as the landing page.
- `/operator/matrix` can use a scoped light theme without changing every deep operator page yet.
- Signal colors remain semantically meaningful rather than being flattened into pure brand styling.

# RISKS / OPEN QUESTIONS

- `/operator/aof`, `/operator/big-win`, and deeper app pages may still need a later visual alignment pass.
- Mobile render passes structurally, but analysis remains desktop-first by product decision.

# OUT OF SCOPE

- No data model changes.
- No Matrix simplification changes.
- No production deploy.
- No global app redesign.

# TEST / VALIDATION

- `npm run build` passed in `frontend`.
- `npm run qa:matrix:render` passed structural layout assertions.
- QA screenshots generated:
  - `/Users/chrisyoon/GitHub/opb-poker/tmp/qa/matrix-render-desktop.png`
  - `/Users/chrisyoon/GitHub/opb-poker/tmp/qa/matrix-render-desktop-full.png`
  - `/Users/chrisyoon/GitHub/opb-poker/tmp/qa/matrix-render-mobile-full.png`
- Visually inspected the desktop full screenshot and corrected remaining low-contrast text.

# RECOMMENDED NEXT STEP

Review `http://localhost:3000/operator/matrix` in the browser. If this color direction feels right, apply the same Clean Felt customer-app treatment to `/app/matrix` next so paid users see the same MVP value surface.
