# TASK
Investigate and correct the misleading `BTN · Limp behind · 1 spot · -16.34bb` Matrix driver display.

# WHAT I CHANGED
- Confirmed the QJs row came from real hand `gg20260303-0414-wsop-sc-25-spring-showers-bounty-turbo:TM96194676`.
- The hand was:
  - QJs on BTN
  - two prior limpers
  - Hero limp-called 1bb
  - flop stack-off at 16.34bb effective
  - final actual result `-16.34bb`
- Updated pinned-detail driver promotion so one-hand tiny preflop-line rows do not outrank repeated non-tiny rows when at least three stable rows exist.
- Updated the top pinned action chip to prioritize non-tiny line evidence before raw stack-result magnitude.
- Added the decision to `DECISIONS_LOG.md`.

# ARCHITECTURE IMPACT
- No raw truth changed.
- No canonical hand result changed.
- This is a surface-ranking correction: tiny postflop stack-off outcomes remain inspectable but are no longer promoted as baseline preflop drivers when repeated evidence exists.

# DECISIONS MADE
- Keep actual-result accounting as full-hand result after Hero enters the pot.
- Do not describe this as preflop EV.
- Treat one-hand stack-off outcomes as example evidence, not primary Matrix driver evidence.

# RISKS / OPEN QUESTIONS
- The UI still needs a future hover/detail affordance for tiny rows so Hero can inspect why a one-off extreme result exists without seeing it as a baseline conclusion.
- A future backend field such as `terminal_preflop_size_bb` or `postflop_stackoff_flag` would make this cleaner.

# OUT OF SCOPE
- No all-in adjusted EV.
- No solver comparison.
- No hand replay viewer.
- No database schema change.

# TEST / VALIDATION
- Confirmed source hand raw payload and result summary.
- `npm run build`
- `npm run qa:matrix:render`

# RECOMMENDED NEXT STEP
Add a compact driver-note line near `ACTUAL RESULT DRIVERS`:

`Rows show final actual hand result after this preflop line; tiny rows are review examples, not baseline conclusions.`
