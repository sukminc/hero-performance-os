# TASK
Merge the Sizing Summary position rows into product position buckets so 9-max-only seats like `UTG+2` do not appear as misleading standalone rows.

# WHAT I CHANGED
- Changed `preflop_sizing_summary.position_rows` to aggregate by the same product buckets used by Matrix drivers:
  - Early = UTG / UTG+1 / UTG+2
  - Mid = LJ / HJ
  - CO
  - BTN
  - SB
  - BB
- Recomputed open average, 2x rate, 3bet average, single-2x 3bet average, and squeeze sizing from merged bucket rows.
- Added `position_bucket_key` and `position_members` to each sizing row so the UI can still show which raw seats are included.
- Updated the sizing table label from `Position` to `Group`.
- Updated the sizing table first column to show bucket name plus raw members.
- Added regression tests for UTG/UTG+2 -> Early and LJ/HJ -> Mid aggregation.
- Updated `DECISIONS_LOG.md`.

# ARCHITECTURE IMPACT
- No raw hand truth changed.
- This is a deterministic derived aggregation change.
- The sizing surface is now aligned with the Matrix preflop-line driver buckets.

# DECISIONS MADE
- Product-facing sizing should avoid raw full-ring seat fragmentation.
- UTG+2 should not look like its own meaningful sample when the user mostly plays 8-max and sometimes 9-max.
- Raw member seats should remain visible under the bucket label for operator trust.

# RISKS / OPEN QUESTIONS
- If later the product needs a pure 9-max specialist view, raw exact-position sizing can be added as an advanced toggle.
- Current MVP should favor fast baseline readability over exact full-ring seat granularity.

# OUT OF SCOPE
- No new filters by table size.
- No separate 6-max / 8-max / 9-max sizing tabs.
- No schema migration.

# TEST / VALIDATION
- `python3 tests/matrix_position_situation_tests.py`
- `python3 tests/matrix_quiz_tests.py`
- `python3 tests/service_boundary_tests.py`
- `npm run build`
- `npm run qa:matrix:render`

# RECOMMENDED NEXT STEP
Add a future filter or toggle for table size once enough user uploads exist:

`All tables / 9-max / 8-max / 6-max`

For MVP, merged buckets are the clearer default.
