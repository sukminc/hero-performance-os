# TASK
Refine Matrix `ACTUAL RESULT DRIVERS` language and sorting so preflop lines read like poker decisions instead of generic action labels.

# WHAT I CHANGED
- Changed preflop-line display labels:
  - BB `call_vs_open` -> `Defend vs open`
  - non-BB `call_vs_open` -> `Call vs open`
  - `limp_behind` -> `Passive entry / over-limp`
  - SB `open_limp_or_complete` -> `SB complete`
  - BB `open_limp_or_complete` -> `BB free check`
- Changed preflop-line row ordering to position bucket first:
  - Early
  - Mid
  - CO
  - BTN
  - SB
  - BB
- Kept same-line ordering inside each position bucket using the existing action sequence: open, open responses, call/passive entry, iso, 3bet, 4bet.
- Added regression tests for BB defend language, passive-entry language, SB complete language, and position-bucket sort order.
- Updated `DECISIONS_LOG.md` with the product decision.

# ARCHITECTURE IMPACT
- No raw hand truth changed.
- No canonical score changed.
- This is a deterministic derived-label and derived-sort improvement.
- The Matrix now better separates defensive range actions from passive multiway entries.

# DECISIONS MADE
- BB call versus an open should use defend language because that is how poker players interpret the action.
- Limp behind should not be presented as a defend; it is a passive multiway entry.
- Position order should be more important than signal magnitude in the main pinned table because Hero is reading ranges by seat family.

# RISKS / OPEN QUESTIONS
- `BB free check` may rarely appear because the current played-pot filter excludes many no-voluntary-entry rows. If later we show BB check-option review, it should remain separate from defend.
- `First size` for call rows still reflects Hero's committed/called amount, not a solver sizing target. This may need a clearer column label later.

# OUT OF SCOPE
- No solver EV.
- No all-in adjusted EV.
- No postflop commitment classifier beyond the existing tiny sample demotion.
- No schema migration.

# TEST / VALIDATION
- `python3 tests/matrix_position_situation_tests.py`
- `python3 tests/matrix_quiz_tests.py`
- `python3 tests/service_boundary_tests.py`
- `npm run build`
- `npm run qa:matrix:render`

# RECOMMENDED NEXT STEP
Rename the `First size` column to something more exact for mixed call/raise rows, such as `Hero put in`, because call rows can show call amount while raise rows show raise-to size.
