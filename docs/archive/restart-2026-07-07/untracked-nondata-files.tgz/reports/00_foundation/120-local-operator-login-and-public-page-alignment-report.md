# TASK

Align remaining public auth/pricing pages with the Clean Felt landing direction and make local login route directly into the operator Matrix.

# WHAT I CHANGED

- Changed the landing `Log In` link in local development to route through dev operator login and land on `/operator/matrix`.
- Reworked `/login` from an old email/password mock into a Clean Felt operator entry page.
- Kept production login as magic-link oriented, while local development shows `Enter Operator Matrix`.
- Updated `/pricing` to match the Clean Felt public-page styling.
- Removed public `Free Beta` pricing language from plan definitions and replaced it with paid Matrix-first plans:
  - `Founding 90-Day Baseline Pass`
  - `Baseline Monthly`
- Updated metadata copy from Ontario-specific to broader GG Poker tournament positioning.

# ARCHITECTURE IMPACT

- Frontend/public funnel change only.
- Local dev login remains cookie-based through the existing `/auth/dev-login` route.
- Paid entitlement is still not wired; this aligns the UI and plan definitions before Stripe checkout work.

# DECISIONS MADE

- Local OPB development should optimize for fast operator QA: landing login goes straight to `/operator/matrix`.
- Public acquisition should no longer advertise free beta access.
- Pricing should sell the Matrix-first MVP, not every internal module.
- Global GG Poker positioning should replace Ontario-only metadata.

# RISKS / OPEN QUESTIONS

- Stripe checkout and post-payment entitlement remain the next hard boundary.
- Existing internal demo application code still exists for historical/operator paths; public pages no longer use it.
- `/app/account`, `/app/review`, and `/app/brain` still inherit deeper app styling and may need a later customer-app visual pass.

# OUT OF SCOPE

- No Stripe checkout implementation.
- No production deployment.
- No data schema migration.
- No operator Matrix visual redesign.

# TEST / VALIDATION

- `npm run build` passed in `frontend`.
- Captured `/login` screenshot: `/private/tmp/opb-login-clean.png`.
- Captured `/pricing` screenshot: `/private/tmp/opb-pricing-paid-clean.png`.
- Verified local dev login with cookie jar from `http://localhost:3000/auth/dev-login?role=operator&next=/operator/matrix` returns `200 OK` at `/operator/matrix`.

# RECOMMENDED NEXT STEP

Wire Stripe checkout and paid entitlement so production users can move from magic link -> payment -> upload -> Matrix without operator provisioning.
