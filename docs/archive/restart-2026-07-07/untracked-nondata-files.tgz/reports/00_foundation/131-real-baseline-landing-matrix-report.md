# TASK
Make the public landing Matrix preview feel real by matching the actual Hero baseline data and color logic.

# WHAT I CHANGED
- Replaced synthetic landing-page Matrix tone generation with aggregated 27,280-hand baseline metrics.
- Changed the preview label from demo/sample language to actual aggregated baseline language.
- Added per-hand-class actual BB labels to the public Matrix preview.
- Matched landing Matrix color classes to the existing Matrix surface tone logic:
  - `very-good`
  - `good`
  - `neutral`
  - `bad`
  - `very-bad`
  - `low-participation`
- Added stack-realization indicator bars using the same tone thresholds as the operator/user Matrix.
- Updated the readout to use real `66` baseline evidence instead of fake `KQo · Watch` copy.
- Deployed the update to Vercel production.
- Re-pointed `onepercentbetter.poker` and `www.onepercentbetter.poker` to the new deployment.

# ARCHITECTURE IMPACT
- No canonical truth changed.
- Public landing now mirrors deterministic derived Matrix truth instead of fabricated preview coloring.
- The preview exposes only aggregated hand-class metrics, not raw hand histories, hand IDs, session IDs, or opponent details.

# DECISIONS MADE
- Used actual aggregated baseline values because the user explicitly approved matching the landing preview to real data.
- Kept the public Matrix as a preview, not an interactive operator surface.
- Preserved the manual founding-access fallback because Supabase production env remains unconfigured.

# RISKS / OPEN QUESTIONS
- Public page now reveals aggregate baseline tendencies. This is acceptable for the current interview use but should be revisited before broad paid launch.
- The constant should eventually be generated from a sanctioned public preview payload rather than embedded in the page component.

# OUT OF SCOPE
- Backend API changes.
- Auth/checkout setup.
- Interactive Matrix details on the public landing page.
- Git commit/push.

# TEST / VALIDATION
- `npm run build` passed locally.
- Local production render captured at `frontend/tmp/opb-real-matrix-landing.png`.
- `vercel deploy --prod -y` completed successfully.
- `vercel alias set` completed for both live poker domains.

# RECOMMENDED NEXT STEP
After the interview, move the public preview data into an explicit sanitized fixture or public-preview API so landing copy stays grounded without hardcoding the aggregate payload in the page.
