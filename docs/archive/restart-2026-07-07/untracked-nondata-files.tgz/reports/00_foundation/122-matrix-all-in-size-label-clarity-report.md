# TASK

Clarify confusing all-in sizing in Matrix pinned detail, especially rows like `99 · SB · Jam / all-in` showing impossible-looking `22.13x` values.

# WHAT I CHANGED

- Split backend position/situation labels so facing an all-in is no longer grouped into Hero `Jam / all-in` rows unless Hero actually jammed.
- Added a regression assertion that Hero jam rows and `Vs all-in` rows stay separate.
- Changed pinned detail column label from `AVG SIZE` to `HERO SIZE`.
- Changed jam/all-in size formatting from `x` to `bb jam`.
- Changed large all-in pressure context from `faced open 23.96x` to `faced all-in/large raise 23.96bb` when applicable.

# ARCHITECTURE IMPACT

- Small deterministic interpretation improvement in Matrix derived grouping.
- No raw parsing schema change.
- No canonical hand truth mutation.
- Existing Matrix payload remains backward-compatible, but rows are now grouped more honestly.

# DECISIONS MADE

- `Jam / all-in` should mean Hero jammed or used a jam entry type.
- Facing an all-in without Hero jamming should display as `Vs all-in`.
- All-in sizing should be shown in big blinds, not `x`.
- Pinned detail should describe Hero's committed size rather than an ambiguous average size.

# RISKS / OPEN QUESTIONS

- Some historical rows may still have mixed proxy pressure where `open_size_bb` represents a large raise/all-in amount rather than a normal open. The UI now labels large values more cautiously, but deeper parser provenance could make this cleaner later.

# OUT OF SCOPE

- No hand-history reparsing.
- No new drill-down modal.
- No example-hand viewer.
- No solver/EV interpretation.

# TEST / VALIDATION

- `python3 tests/matrix_position_situation_tests.py` passed.
- `npm run build` passed in `frontend`.
- `npm run qa:matrix:render` passed structural layout assertions.

# RECOMMENDED NEXT STEP

Add a small example-hand drill-down from pinned detail rows so confusing all-in buckets can show the exact hand IDs and action summaries behind the average.
