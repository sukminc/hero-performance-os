# TASK

Replace the public signup page's founding-access request form with a SaaS-style email magic-link entry flow for paid Matrix access.

# WHAT I CHANGED

- Reworked `/signup` copy away from "request founding access" and beta/demo application language.
- Replaced the multi-field demo application form on `/signup` with a single email magic-link form.
- Added a real Supabase `signInWithOtp` server action for sending magic links when Supabase auth environment variables are configured.
- Added `/auth/callback` to exchange Supabase auth codes and set session cookies.
- Positioned access as paid-only: email magic link -> paid membership -> upload GG history -> 13x13 Matrix.
- Added product-truth notes to `docs/active_task.md` and `DECISIONS_LOG.md`.

# ARCHITECTURE IMPACT

- Adds the first real public magic-link auth entry point.
- Does not grant player access by email alone.
- Real Matrix data remains protected by the existing viewer/player access resolution.
- Payment entitlement is still not implemented; this change prepares the entry point but does not create checkout.

# DECISIONS MADE

- Public acquisition should not use demo/test-user application language.
- Public signup should ask for email only.
- Magic-link authentication and paid membership should be separate from actual Matrix data entitlement.
- Public previews must continue using sample data only.

# RISKS / OPEN QUESTIONS

- Supabase auth must be configured in production for magic links to send.
- Stripe checkout still needs to be wired between auth and paid entitlement.
- Existing internal demo application tooling remains in the repo for operator history, but it is no longer the public signup path.

# OUT OF SCOPE

- Stripe checkout implementation.
- Paid entitlement provisioning.
- Removing internal operator demo-application tools.
- Production deployment.

# TEST / VALIDATION

- `npm run build` passed in `frontend`.
- Desktop screenshot captured: `/private/tmp/opb-signup-paid-desktop.png`.
- Mobile screenshot captured: `/private/tmp/opb-signup-paid-mobile.png`.

# RECOMMENDED NEXT STEP

Wire the post-magic-link step to Stripe checkout, then provision paid player access so successful payment routes users to upload and their Matrix.
