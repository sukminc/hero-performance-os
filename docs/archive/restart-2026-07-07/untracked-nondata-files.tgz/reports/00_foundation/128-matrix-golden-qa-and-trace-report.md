# Matrix Golden QA and Trace Report

Generated: `2026-07-07T17:39:23+00:00`
Player: `4c9d1e29-1f6b-4e5f-92da-111111111111`

## TASK

Prepare objective QA material for tomorrow's product review without requiring live operator decisions.

## WHAT I CHECKED

- Matrix cell calculation policy: played pots drive performance; dealt folds remain exposure context.
- Golden hand classes: `99`, `A5s`, `KJo`, `AQo`, `AKo`, `83o`.
- Preflop line breakdowns, important losing lines, low-participation behavior, and raw hand traceability.
- 3bet-fold candidates versus a solver-principle proxy, not an exact solver node.

## Baseline Consistency Snapshot

- Total hands: `27280`
- Open baseline: avg `2.13x`, mode `2.0x`, near-2x `82.8%`
- HU 3bet vs 2x baseline: avg `6.35x`, mode `6.0x`, clean spots `307`
- AOF baseline: avg `14.95bb`, median `12.21bb`, jams `720`

## QA Interpretation Guardrails

- This report uses actual final hand result after a preflop line; it is not solver EV or all-in adjusted EV.
- One-hand postflop stack-offs are examples, not baseline conclusions.
- Solver comparison here means blocker/realization/position/stack proxy review only.

## 99

| Metric | Value |
| --- | ---: |
| Dealt | 122 |
| Played | 116 |
| No entry | 6 |
| Participation | 95.1% |
| Avg BB / played hand | 3.62bb |
| Avg stack realization | 9.67% |
| Low participation neutralized | False |

**Current read:** The result issue is concentrated in CO Call vs open, so treat it as a spot review before changing the whole hand class.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open | 16 spots | 2.75bb | 1.85bb | -0.91% | UTG 13 / UTG+1 3 |
| Early · Open -> flat 3bet | 5 spots | 2.0bb | -0.31bb | 5.34% | UTG 4 / UTG+1 1 |
| Mid · Open | 6 spots | 2.03bb | 17.89bb | 26.0% | HJ 4 / LJ 2 |
| CO · Open | 5 spots | 2.0bb | 2.37bb | 0.34% |  |
| CO · Call vs open | 6 spots | 2.78bb | 15.44bb | -8.46% | faced avg 9.56bb |
| BTN · Open | 8 spots | 2.56bb | 1.31bb | 8.26% |  |
| BTN · Call vs open | 7 spots | 5.38bb | 3.19bb | 16.47% | faced avg 2.82bb |
| BB · Defend vs open | 7 spots | 4.15bb | 2.07bb | 24.35% | faced avg 3.0bb |

### Important Losing Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| CO · Call vs open | 6 spots | 2.78bb | 15.44bb | -8.46% | faced avg 9.56bb |
| BTN · 3bet jam | 2 spots | 6.61bb | -6.61bb | -97.39% | faced avg 2.5bb |
| BB · 3bet jam | 3 spots | 20.46bb | -11.78bb | -62.68% | faced avg 2.67bb |
| Mid · Open -> flat 3bet | 3 spots | 2.07bb | 0.73bb | -12.11% | HJ 2 / LJ 1 |
| SB · Call vs open | 3 spots | 2.5bb | -12.54bb | -7.54% | faced avg 18.76bb |
| SB · Flat vs 3bet | 2 spots | 5.32bb | -4.34bb | -7.28% | faced avg 177.02bb |

### Raw Trace Examples

- `gg20260429-0312-tuesday-heater-25-bounty-turbo:TM101837713`
  - started: `2026/04/29 00:02:20` · stack: `32.91bb`
  - summary: Seat 2: Hero showed [9d 9c] and lost with three of a kind, Nines
  - hero actions: Hero: posts the ante 120 / Hero: calls 1,760 / Hero: calls 3,487 / Hero: checks / Hero: calls 2,574 / Hero: checks / Hero: bets 18,391 and is all-in / Hero: shows [9d 9c] (three of a kind, Nines)
  - preflop trace: 164425e2: folds / 3d697621: folds / f1986420: raises 960 to 1,760 / Hero: calls 1,760 / 55fce98b: raises 3,487 to 5,247 / 992bcbd9: folds / a28dd523: folds / f1986420: folds
- `gg20260424-2300-105-bounty-king-ultradeep-turbo:TM101476177`
  - started: `2026/04/24 21:13:49` · stack: `233.46bb`
  - summary: Seat 2: Hero showed [9s 9c] and won (75,164) with two pair, Nines and Threes
  - hero actions: Hero: posts the ante 35 / Hero: calls 1,200 / Hero: raises 5,400 to 9,000 / Hero: bets 32,778 / Hero: shows [9s 9c] (a pair of Nines)
  - preflop trace: 99168b67: raises 900 to 1,200 / 35447c46: folds / 5d106b92: folds / efd3d1c6: calls 1,200 / Hero: calls 1,200 / ccac944a: folds / ba0bea38: calls 1,050 / 96295931: calls 900
- `gg20260424-0141-mini-thursday-throwdown-25-bounty:TM101368938`
  - started: `2026/04/24 01:37:00` · stack: `43.65bb`
  - summary: Seat 6: Hero won (21,550)
  - hero actions: Hero: posts the ante 350 / Hero: calls 5,000 / Hero: bets 8,620
  - preflop trace: 5dc8e4ed: folds / 66a6239d: folds / b7e1042a: folds / d8959293: raises 2,500 to 5,000 / Hero: calls 5,000 / c14f2bac: calls 5,000 / cc281766: folds / 26ab0af8: folds

### Tomorrow Review Question

- Does the losing evidence concentrate in 25-35bb high-pressure commitment, or is the whole hand class overplayed?

## A5s

| Metric | Value |
| --- | ---: |
| Dealt | 64 |
| Played | 60 |
| No entry | 4 |
| Participation | 93.8% |
| Avg BB / played hand | -1.48bb |
| Avg stack realization | -5.26% |
| Low participation neutralized | False |

**Current read:** The result issue is concentrated in UTG Open, so treat it as a spot review before changing the whole hand class.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open | 11 spots | 2.27bb | 0.56bb | 6.41% | UTG+1 8 / UTG 3 |
| Mid · Open | 5 spots | 2.04bb | 2.64bb | 8.8% | HJ 3 / LJ 2 |
| CO · Open | 8 spots | 2.94bb | -0.49bb | 4.86% |  |

### Important Losing Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open -> flat 3bet | 3 spots | 3.23bb | -6.75bb | -58.99% |  |
| Early · Open -> 4bet | 2 spots | 2.0bb | -8.07bb | -12.98% | UTG 1 / UTG+1 1 |
| SB · 3bet | 3 spots | 7.4bb | -16.39bb | -9.7% | faced avg 2.37bb |

### Raw Trace Examples

- `gg20260302-2013-1-step-to-wsop-c-playground-main-event:TM96172394`
  - started: `2026/03/02 16:41:13` · stack: `16.41bb`
  - summary: Seat 7: Hero showed [Ad 5d] and lost with two pair, Sevens and Fours
  - hero actions: Hero: posts the ante 100 / Hero: raises 1,000 to 2,000 / Hero: calls 7,900 / Hero: shows [Ad 5d]
  - preflop trace: Hero: raises 1,000 to 2,000 / bd311258: folds / 2d8e0fc9: folds / bbdce0e0: folds / b6c1e02a: folds / f800404c: folds / 8f0770da: folds / fcab0cad: raises 7,900 to 9,900 and is all-in
- `gg20260128-0434-tuesday-heater-25-bounty-turbo:TM92990424`
  - started: `2026/01/28 01:24:59` · stack: `5.9bb`
  - summary: Seat 1: Hero showed [Ac 5c] and lost with a pair of Fives
  - hero actions: Hero: posts the ante 350 / Hero: raises 11,750 to 14,250 / Hero: calls 160 and is all-in / Hero: shows [Ac 5c]
  - preflop trace: Hero: raises 11,750 to 14,250 / 6986ace4: folds / 91d05ac9: folds / 156976d3: folds / 8379c56c: folds / 190e7a6: folds / 117fc65a: folds / 99a47cd5: raises 11,750 to 26,000
- `gg20260118-0119-35-30-ultra-stack:TM91921288`
  - started: `2026/01/17 22:31:17` · stack: `24.22bb`
  - summary: Seat 1: Hero folded on the Flop
  - hero actions: Hero: posts the ante 600 / Hero: raises 5,000 to 10,000 / Hero: calls 12,936 / Hero: checks / Hero: folds
  - preflop trace: Hero: raises 5,000 to 10,000 / fdfbf529: folds / 8854923f: calls 10,000 / f3aaf807: folds / 3168c3fb: folds / 480fcf21: raises 12,936 to 22,936 / c410b6a: folds / Hero: calls 12,936

### Tomorrow Review Question

- Are the losing rows true 3bet-bluff selection mistakes, or one-off postflop/all-in outcomes?

## KJo

| Metric | Value |
| --- | ---: |
| Dealt | 216 |
| Played | 192 |
| No entry | 24 |
| Participation | 88.9% |
| Avg BB / played hand | -0.75bb |
| Avg stack realization | 0.37% |
| Low participation neutralized | False |

**Current read:** The result issue is concentrated in BTN Jam / all-in, so treat it as a spot review before changing the whole hand class.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open | 23 spots | 2.42bb | 0.7bb | 3.02% | UTG 14 / UTG+1 9 |
| Early · Open -> flat 3bet | 7 spots | 2.06bb | -9.24bb | -12.12% | UTG 5 / UTG+1 2 |
| Early · Open jam | 5 spots | 12.45bb | -3.23bb | -8.87% | UTG 4 / UTG+1 1 |
| Mid · Open | 19 spots | 2.8bb | 1.91bb | 1.13% | HJ 12 / LJ 7 |
| Mid · Call vs open | 6 spots | 2.57bb | -7.73bb | -32.49% | faced avg 14.37bb |
| Mid · 3bet | 5 spots | 6.44bb | 5.04bb | 16.5% | faced avg 2.24bb |
| CO · Open | 14 spots | 2.57bb | -0.65bb | -1.43% |  |
| CO · Call vs open | 6 spots | 2.08bb | -0.87bb | -1.74% | faced avg 2.08bb |

### Important Losing Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Mid · Call vs open | 6 spots | 2.57bb | -7.73bb | -32.49% | faced avg 14.37bb |
| Early · Open -> flat 3bet | 7 spots | 2.06bb | -9.24bb | -12.12% | UTG 5 / UTG+1 2 |
| SB · Call vs open | 6 spots | 1.63bb | -2.0bb | -9.96% | faced avg 2.13bb |
| Early · Open jam | 5 spots | 12.45bb | -3.23bb | -8.87% | UTG 4 / UTG+1 1 |
| BTN · Call vs open | 11 spots | 2.5bb | -2.92bb | -6.42% | faced avg 9.26bb |
| BTN · Iso raise | 2 spots | 5.17bb | -12.84bb | -52.55% |  |

### Raw Trace Examples

- `gg20260412-0006-mini-saturday-knockout-25-bounty:TM100204757`
  - started: `2026/04/11 20:25:31` · stack: `116.75bb`
  - summary: Seat 5: Hero folded on the Turn
  - hero actions: Hero: posts the ante 60 / Hero: calls 1,880 / Hero: calls 2,420 / Hero: folds
  - preflop trace: 19e1b480: folds / 2fd97e58: raises 1,480 to 1,880 / 36cb1eed: folds / Hero: calls 1,880 / eb110f31: folds / ab497bf3: folds / 6e6a491c: folds / 1cc618fb: folds
- `gg20260329-1913-20-mega-to-ggmasters-150-30-seats:TM98908183`
  - started: `2026/03/29 15:16:09` · stack: `14.7bb`
  - summary: Seat 5: Hero showed [Js Kc] and lost with two pair, Kings and Eights
  - hero actions: Hero: posts the ante 50 / Hero: calls 1,000 / Hero: calls 6,300 and is all-in / Hero: shows [Js Kc]
  - preflop trace: 87aab5a1: raises 500 to 1,000 / 5f39faee: calls 1,000 / ef5790f5: folds / Hero: calls 1,000 / cda8e3d8: calls 1,000 / b92b0720: calls 1,000 / b13eca36: raises 9,836 to 10,836 and is all-in / 21cadc9: folds
- `gg20260329-0106-mini-saturday-knockout-25-bounty:TM98904367`
  - started: `2026/03/28 23:48:39` · stack: `25.43bb`
  - summary: Seat 1: Hero showed [Jc Kd] and lost with a pair of Aces
  - hero actions: Hero: posts the ante 3,000 / Hero: calls 50,000 / Hero: raises 36,000 to 62,000 / Hero: bets 79,750 / Hero: checks / Hero: shows [Jc Kd] (a pair of Aces)
  - preflop trace: 3ab72d98: raises 30,000 to 50,000 / c6c43ad0: folds / Hero: calls 50,000 / 72ff1383: folds / 65bc7e18: folds / 2fa79fe5: folds / af5b16c7: folds

### Tomorrow Review Question

- Does the data support keeping KJo as a selective 3bet-bluff candidate while avoiding passive large-pressure calls?

## AQo

| Metric | Value |
| --- | ---: |
| Dealt | 264 |
| Played | 259 |
| No entry | 5 |
| Participation | 98.1% |
| Avg BB / played hand | 1.42bb |
| Avg stack realization | 9.64% |
| Low participation neutralized | False |

**Current read:** AQo should not be cut from normal open/defend baselines just because this actual-result sample is negative; the first review target is BB Call vs open.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open | 38 spots | 3.93bb | 1.35bb | 4.31% | UTG 24 / UTG+1 14 |
| Early · Open -> flat 3bet | 7 spots | 3.0bb | -2.27bb | -15.63% | UTG+1 6 / UTG 1 |
| Early · Open jam | 8 spots | 13.56bb | 6.13bb | 51.23% | UTG 6 / UTG+1 2 |
| Mid · Open | 10 spots | 3.7bb | 7.43bb | 19.87% | HJ 5 / LJ 5 |
| Mid · Iso raise | 5 spots | 5.58bb | 8.24bb | 21.59% | HJ 3 / LJ 2 |
| Mid · 3bet | 8 spots | 8.63bb | 1.81bb | 16.83% | faced avg 2.04bb · HJ 5 / LJ 3 |
| CO · Open | 12 spots | 2.06bb | -1.72bb | -3.15% |  |
| CO · Iso raise | 5 spots | 5.1bb | 9.54bb | 29.77% |  |

### Important Losing Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| BTN · Call vs open | 7 spots | 6.95bb | -13.95bb | -28.65% | faced avg 2.7bb |
| Early · Open -> flat 3bet | 7 spots | 3.0bb | -2.27bb | -15.63% | UTG+1 6 / UTG 1 |
| CO · 3bet | 10 spots | 8.49bb | -7.58bb | -4.77% | faced avg 2.04bb |
| CO · Open | 12 spots | 2.06bb | -1.72bb | -3.15% |  |
| BB · Defend vs open | 11 spots | 4.4bb | -5.74bb | 2.37% | faced avg 2.17bb |
| BTN · 3bet jam | 5 spots | 18.69bb | -2.92bb | 19.71% | faced avg 2.7bb |

### Raw Trace Examples

- `gg20260429-0036-bounty-king-jr-10-50:TM101876998`
  - started: `2026/04/28 21:46:34` · stack: `23.5bb`
  - summary: Seat 3: Hero (button) folded on the River
  - hero actions: Hero: posts the ante 200 / Hero: calls 2,800 / Hero: bets 3,646 / Hero: checks / Hero: folds
  - preflop trace: eaa9d1c1: folds / 38ec2f51: folds / d20b5e0a: raises 1,400 to 2,800 / 343345ac: calls 2,800 / 9e2a3539: folds / Hero: calls 2,800 / 4feb1fc7: folds / 84359549: calls 1,400
- `gg20260411-2022-6-satellite-to-ontario-million-bounty-100k-gtd-3-seats:TM100099953`
  - started: `2026/04/11 17:34:25` · stack: `38.56bb`
  - summary: Seat 7: Hero (button) won (4,825)
  - hero actions: Hero: posts the ante 25 / Hero: calls 750 / Hero: raises 1,000 to 1,750
  - preflop trace: 540abb10: folds / 1c26e9ce: folds / f1ee001a: raises 500 to 750 / 53dd88f: calls 750 / a7b4a79c: folds / Hero: calls 750 / 9ff201cd: folds / d905db21: calls 500
- `gg20260403-0300-ontario-million-100k-gtd-day-1:TM99430003`
  - started: `2026/04/03 01:19:42` · stack: `91.6bb`
  - summary: Seat 2: Hero (button) folded on the Turn
  - hero actions: Hero: posts the ante 125 / Hero: calls 3,000 / Hero: calls 4,500 / Hero: calls 6,300 / Hero: folds
  - preflop trace: bad27c4f: folds / 2f044708: raises 2,000 to 3,000 / Hero: calls 3,000 / 53f973d: folds / 3ebfb994: calls 2,000

### Tomorrow Review Question

- Are repeated 3bet-folds disciplined folds versus tight 4bet ranges, or is AQo being turned into a bluff too often?

## AKo

| Metric | Value |
| --- | ---: |
| Dealt | 231 |
| Played | 221 |
| No entry | 10 |
| Participation | 95.7% |
| Avg BB / played hand | 3.25bb |
| Avg stack realization | 11.86% |
| Low participation neutralized | False |

**Current read:** The result issue is concentrated in SB Jam / all-in, so treat it as a spot review before changing the whole hand class.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| Early · Open | 31 spots | 2.2bb | 4.02bb | 1.7% | UTG 18 / UTG+1 13 |
| Early · Open -> flat 3bet | 11 spots | 4.12bb | 3.31bb | 14.07% | UTG 8 / UTG+1 3 |
| Early · Open jam | 5 spots | 12.8bb | 2.35bb | 20.56% | UTG 4 / UTG+1 1 |
| Mid · Open | 14 spots | 2.94bb | -1.09bb | 1.06% | HJ 11 / LJ 3 |
| Mid · 3bet | 10 spots | 7.31bb | 9.83bb | 34.79% | faced avg 2.29bb · HJ 6 / LJ 4 |
| CO · Open | 11 spots | 3.79bb | -1.04bb | 0.8% |  |
| CO · Open -> 4bet | 6 spots | 2.08bb | -24.18bb | -9.66% |  |
| CO · 3bet | 5 spots | 6.46bb | 10.06bb | 38.61% | faced avg 2.38bb |

### Important Losing Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| CO · Open -> 4bet | 6 spots | 2.08bb | -24.18bb | -9.66% |  |
| CO · Open | 11 spots | 3.79bb | -1.04bb | 0.8% |  |
| Mid · Open | 14 spots | 2.94bb | -1.09bb | 1.06% | HJ 11 / LJ 3 |
| SB · Iso jam | 2 spots | 16.13bb | -16.14bb | -99.25% |  |
| BB · Flat vs 3bet | 2 spots | 18.54bb | -19.67bb | -73.2% |  |
| CO · Open -> flat 3bet | 2 spots | 7.35bb | 0.42bb | -30.84% |  |

### Raw Trace Examples

- `gg20260429-0205-tuesday-heater-25-bounty-turbo:TM101836972`
  - started: `2026/04/28 23:09:30` · stack: `117.73bb`
  - summary: Seat 6: Hero showed [Kd Ah] and lost with Ace high
  - hero actions: Hero: posts the ante 30 / Hero: raises 200 to 400 / Hero: raises 2,995 to 4,400 / Hero: raises 9,777 to 23,517 and is all-in / Hero: shows [Kd Ah]
  - preflop trace: 52912d92: folds / a5847dff: folds / eb65a5dc: folds / f6f5a039: folds / Hero: raises 200 to 400 / a600a991: raises 1,005 to 1,405 / 6e95888: folds / c4c3c2bb: folds
- `gg20260419-0416-15-satellite-to-ggmasters-150-1-seat:TM100927378`
  - started: `2026/04/19 00:22:49` · stack: `54.22bb`
  - summary: Seat 6: Hero showed [Kd As] and won (5,431) with Ace high
  - hero actions: Hero: posts the ante 10 / Hero: raises 100 to 200 / Hero: raises 1,200 to 2,200 / Hero: calls 3,106 / Hero: shows [Kd As]
  - preflop trace: eadbfa4b: folds / Hero: raises 100 to 200 / 2e1adad6: folds / 4f3f4141: calls 150 / 63986eb6: raises 800 to 1,000 / Hero: raises 1,200 to 2,200 / 4f3f4141: folds / 63986eb6: raises 3,106 to 5,306 and is all-in
- `gg20260411-0005-mini-friday-night-fight-25-bounty-6-max:TM100124094`
  - started: `2026/04/10 20:21:45` · stack: `106.45bb`
  - summary: Seat 3: Hero showed [Ah Kd] and lost with Ace high
  - hero actions: Hero: posts the ante 75 / Hero: raises 750 to 1,250 / Hero: raises 9,022 to 12,500 / Hero: bets 8,022 / Hero: calls 32,629 and is all-in / Hero: shows [Ah Kd] (Ace high)
  - preflop trace: 865f8e: folds / Hero: raises 750 to 1,250 / 9178fcc0: folds / 61a58c0f: raises 2,228 to 3,478 / 11da9f81: folds / Hero: raises 9,022 to 12,500 / 61a58c0f: calls 9,022

### Tomorrow Review Question

- Is the AKo 3bet-fold explained by ICM/satellite/field context, or should it be a golden review hand?

## 83o

| Metric | Value |
| --- | ---: |
| Dealt | 219 |
| Played | 1 |
| No entry | 218 |
| Participation | 0.5% |
| Avg BB / played hand | 2.4bb |
| Avg stack realization | 3.49% |
| Low participation neutralized | True |

**Current read:** Hero played this hand class only 0.5% of the times it was dealt, so the Matrix should stay neutral instead of treating the tiny result as a core signal.

### Primary Stable Lines

| Line | Count | Hero size | Actual BB | Stack | Context |
| --- | ---: | ---: | ---: | ---: | --- |
| BB · Iso raise | 1 spot | 3.0bb | 2.4bb | 3.49% |  |

### Important Losing Lines

No repeated losing preflop-line row met the QA threshold.

### Raw Trace Examples

- `gg20260418-0330-25-friday-heater-turbo:TM100900158`
  - started: `2026/04/18 02:08:51` · stack: `68.81bb`
  - summary: Seat 2: Hero (big blind) collected (34,000)
  - hero actions: Hero: posts the ante 1,500 / Hero: posts big blind 10,000 / Hero: raises 20,000 to 30,000
  - preflop trace: fa1b790e: folds / f7e1c1e9: calls 10,000 / 478a2c3d: folds / ea967c21: folds / edfbb838: folds / Hero: raises 20,000 to 30,000 / f7e1c1e9: folds

### Tomorrow Review Question

- Does low-participation neutralization keep trash hands out of the core Matrix signal?

## 3bet-Fold Review

- Clean 3bet rows: `638`
- Faced 4bet after 3bet: `158`
- Folded to 4bet: `26`
- Fold rate after facing 4bet: `16.5%`

| Hand | Count | Buckets | Proxy read |
| --- | ---: | --- | --- |
| AQo | 5 | SB 1, BB 1, Early 1, CO 1, BTN 1 | Priority review, not automatic solver-aligned |
| ATo | 3 | CO 2, Mid 1 | Mixed blocker/value-bluff boundary |
| KQo | 3 | Mid 2, Early 1 | Mixed blocker/value-bluff boundary |
| A5s | 2 | BTN 1, Mid 1 | Natural bluff-candidate fold |
| A8o | 2 | SB 1, CO 1 | Loose blocker bluff candidate; watch frequency |
| A8s | 2 | Early 1, BTN 1 | Mixed blocker/value-bluff boundary |
| 87s | 1 | BTN 1 | Natural bluff-candidate fold |
| A3s | 1 | Mid 1 | Natural bluff-candidate fold |
| A6o | 1 | BB 1 | Loose blocker bluff candidate; watch frequency |
| AKo | 1 | Mid 1 | Priority review, not automatic solver-aligned |
| K5s | 1 | SB 1 | Natural bluff-candidate fold |
| K9o | 1 | BTN 1 | Loose blocker bluff candidate; watch frequency |
| KJo | 1 | BTN 1 | Mixed blocker/value-bluff boundary |
| Q9s | 1 | BB 1 | Natural bluff-candidate fold |
| QTs | 1 | Mid 1 | Natural bluff-candidate fold |

### Priority Raw Trace

These are not proof of mistakes; they are the highest-leverage tomorrow-review candidates.

- `A5s` `BTN` `BTN` stack `27.57bb` open `3.0bb` 3bet `9.0bb` -> folded to 4bet
  - hand: `gg20260426-1844-10-satellite-to-mystery-bounty-main-event-250k-gtd-1-seat:TM101599471`
  - summary: Seat 7: Hero (button) folded before Flop
- `A5s` `Mid` `HJ` stack `25.0bb` open `2.0bb` 3bet `6.0bb` -> folded to 4bet
  - hand: `gg20260107-2343-25-daily-merrython:TM90817413`
  - summary: Seat 2: Hero folded before Flop
- `AKo` `Mid` `LJ` stack `45.54bb` open `2.0bb` 3bet `6.5bb` -> folded to 4bet
  - hand: `gg20260401-0236-wsop-sc-25-spring-showers-bounty-turbo:TM99167420`
  - summary: Seat 3: Hero folded before Flop
- `AQo` `BB` `BB` stack `34.8bb` open `4.0bb` 3bet `8.8bb` -> folded to 4bet
  - hand: `gg20260410-1726-bounty-hunters-5-25:TM100067691`
  - summary: Seat 3: Hero (big blind) folded before Flop
- `AQo` `BTN` `BTN` stack `81.53bb` open `3.0bb` 3bet `7.0bb` -> folded to 4bet
  - hand: `gg20260115-0124-25-winter-wonderbox-mystery-bounty:TM91603669`
  - summary: Seat 7: Hero (button) folded before Flop
- `AQo` `CO` `CO` stack `89.69bb` open `2.0bb` 3bet `6.0bb` -> folded to 4bet
  - hand: `gg20260207-0303-mini-friday-night-fight-25-bounty-6-max:TM93883806`
  - summary: Seat 5: Hero folded before Flop
- `AQo` `SB` `SB` stack `88.32bb` open `4.5bb` 3bet `9.0bb` -> folded to 4bet
  - hand: `gg20260427-2031-10-step-to-wsop-c-playground-main-event-75-satellite:TM101727012`
  - summary: Seat 5: Hero (small blind) folded before Flop
- `AQo` `Early` `UTG+1` stack `159.68bb` open `3.0bb` 3bet `8.0bb` -> folded to 4bet
  - hand: `gg20260210-0105-mini-monday-monster-stack-25:TM94171128`
  - summary: Seat 4: Hero folded before Flop
- `ATo` `CO` `CO` stack `94.18bb` open `2.0bb` 3bet `6.0bb` -> folded to 4bet
  - hand: `gg20260207-0303-mini-friday-night-fight-25-bounty-6-max:TM93883625`
  - summary: Seat 5: Hero folded before Flop
- `ATo` `CO` `CO` stack `83.0bb` open `1.94bb` 3bet `5.4bb` -> folded to 4bet
  - hand: `gg20260418-0032-mini-friday-night-fight-25-bounty-6-max:TM100836536`
  - summary: Seat 6: Hero folded before Flop
- `ATo` `Mid` `HJ` stack `31.4bb` open `2.0bb` 3bet `6.0bb` -> folded to 4bet
  - hand: `gg20260420-0219-sunday-heater-25-bounty-turbo:TM101110397`
  - summary: Seat 4: Hero folded before Flop
- `KJo` `BTN` `BTN` stack `87.78bb` open `2.0bb` 3bet `6.0bb` -> folded to 4bet
  - hand: `gg20260212-0305-wednesday-heater-25-bounty-turbo:TM94294228`
  - summary: Seat 8: Hero (button) folded before Flop

## RISKS / OPEN QUESTIONS

- `Call vs open` still needs pressure buckets: normal open, large open, and jam/all-in pressure.
- `Hero size` / `First size` language still needs one final UX decision because call rows and raise rows mean different things.
- 99/AQo/AKo need human strategy review before turning any finding into product copy.

## OUT OF SCOPE

- No code behavior changed by this report generation.
- No solver import or exact GTO lookup.
- No paid-user UI changes.

## TEST / VALIDATION

- Generated from current Matrix backend payload and local Hero SQLite truth.
- Raw hand ids in the report are queryable in local storage.
- Validation commands for this task: `python3 scripts/matrix_golden_qa.py`, `python3 tests/matrix_position_situation_tests.py`, `python3 tests/matrix_quiz_tests.py`, `python3 tests/service_boundary_tests.py`.

## RECOMMENDED NEXT STEP

Tomorrow, review only these decisions:

1. Does the 99 high-pressure interpretation match Hero's lived baseline shift?
2. Does KJo read as a selective 3bet-bluff hand rather than a range cut?
3. Are AQo/AKo 3bet-folds disciplined exploit folds or red-flag weak folds?
4. Should product copy say `Actual BB` or `Final result`?
5. Which golden hand should become the first public demo story?
