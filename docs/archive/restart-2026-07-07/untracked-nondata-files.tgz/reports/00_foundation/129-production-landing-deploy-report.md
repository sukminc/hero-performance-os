# TASK
Deploy the latest local public landing page to production before an interview, while avoiding broken public magic-link signup if Supabase production env is not configured.

# WHAT I CHANGED
- Checked Vercel production env vars for the linked frontend project.
- Found no Vercel environment variables configured, including `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- Changed public acquisition CTAs from `Get My Matrix` to `Request Founding Access`.
- Replaced `/signup` magic-link form with a static manual founding-access contact path.
- Updated the missing-auth fallback message so production users do not see local-environment language.
- Deployed the current frontend build to Vercel production.
- Re-pointed `onepercentbetter.poker` and `www.onepercentbetter.poker` aliases to the new deployment.

# ARCHITECTURE IMPACT
- Keeps Supabase as an edge auth/access mechanism, but does not expose a broken auth path before production env is ready.
- Does not change canonical product truth, parsing, player memory, Matrix truth, or backend interpretation logic.
- Keeps the public surface acquisition-oriented while backend/operator truth remains the product priority.

# DECISIONS MADE
- Did not use the older demo application form because it depends on Python subprocess execution from Next.js, which is not appropriate for real beta production traffic.
- Used a static manual founding-access CTA as the safest interview-ready fallback.
- Treated `onepercentbetter.poker` and `www.onepercentbetter.poker` as the live poker production domains based on Vercel alias state.

# RISKS / OPEN QUESTIONS
- `opb.poker` was not present in the Vercel domain list; the configured poker domains are `onepercentbetter.poker` and `www.onepercentbetter.poker`.
- `mailto:founding@opb.poker` should be confirmed or replaced with the real intake address if that mailbox is not configured.
- Login remains visible, but failed magic-link attempts now return a public-safe manual-access message.

# OUT OF SCOPE
- Full Supabase production auth setup.
- Stripe checkout wiring.
- Backend/session/Matrix changes.
- Git commit or PR creation.

# TEST / VALIDATION
- `vercel env ls` showed no env vars for the linked frontend project.
- `npm run build` passed locally.
- Local production server rendered `/` and `/signup`.
- Captured screenshots:
  - `frontend/tmp/opb-prod-ready-landing.png`
  - `frontend/tmp/opb-prod-ready-signup.png`
- `vercel deploy --prod -y` completed successfully.
- `vercel alias ls` confirmed both `onepercentbetter.poker` and `www.onepercentbetter.poker` point to `frontend-otq0jvxnv-sukmincs-projects.vercel.app`.

# RECOMMENDED NEXT STEP
Confirm the real founding-access inbox, then either keep the manual CTA for interview use or configure Supabase production env and restore the magic-link signup flow.
