# TASK
Reorganize the AOF Baseline section so position and action language matches the rest of the Matrix MVP.

# WHAT I CHANGED
- Merged AOF by-position rows into product buckets:
  - Early = UTG / UTG+1 / UTG+2
  - Mid = LJ / HJ
  - CO
  - BTN
  - SB
  - BB
- Added `position_bucket_key` and `position_members` to AOF position rows.
- Replaced raw AOF action keys with readable jam families:
  - `open_raise_jam` -> `Open jam`
  - `iso_raise_jam` -> `Iso jam`
  - `three_bet_jam` -> `3bet jam`
  - `four_bet_jam` -> `4bet jam`
  - `five_bet_plus_jam` -> `5bet+ jam`
- Updated repeated big-minus clusters to use position buckets and jam-family labels.
- Updated the AOF UI headings:
  - `By Action` -> `By Jam Type`
  - `By Position` -> `By Position Group`
- Updated detail popovers and repeated big-minus chips to show readable action labels.
- Added regression tests for AOF bucket merging and action labels.
- Updated `DECISIONS_LOG.md`.

# ARCHITECTURE IMPACT
- No raw hand truth changed.
- AOF remains a deterministic derived layer.
- The AOF surface now uses the same position language as sizing summary and Matrix result drivers.

# DECISIONS MADE
- Product-facing AOF should not expose raw parser keys as primary language.
- Full-ring-only seats should not appear as standalone AOF rows in the MVP default view.
- Big-loss clusters should cluster by hand class + position bucket + jam family, not exact raw seat + raw entry type.

# RISKS / OPEN QUESTIONS
- A future advanced toggle may still need exact raw seat rows for full-ring specialists.
- Jam-family order may need product tuning after Hero reviews the revised page.

# OUT OF SCOPE
- No solver shove chart.
- No all-in adjusted EV.
- No table-size filter.
- No schema migration.

# TEST / VALIDATION
- `python3 tests/matrix_position_situation_tests.py`
- `python3 tests/matrix_quiz_tests.py`
- `python3 tests/service_boundary_tests.py`
- `npm run build`
- `npm run qa:matrix:render`

# RECOMMENDED NEXT STEP
Add a future `All tables / 9-max / 8-max / 6-max` filter only after more user uploads exist. For MVP, bucketed position groups are the clearer default.
