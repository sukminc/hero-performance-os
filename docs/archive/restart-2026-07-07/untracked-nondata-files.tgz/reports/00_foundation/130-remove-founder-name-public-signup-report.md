# TASK
Remove the founder's personal name from the public founding-access signup page and redeploy production.

# WHAT I CHANGED
- Updated `/signup` headline from `Unlock your Matrix with Chris` to `Unlock your personal Matrix`.
- Updated the setup CTA heading from `Message Chris for the first setup` to `Request your first setup`.
- Deployed the updated frontend to Vercel production.
- Re-pointed `onepercentbetter.poker` and `www.onepercentbetter.poker` to the new deployment.

# ARCHITECTURE IMPACT
- Public acquisition copy is less founder-specific and more product-facing.
- No backend, auth, parsing, Matrix, or player-memory behavior changed.

# DECISIONS MADE
- Kept the manual founding-access fallback because Vercel production env still lacked Supabase auth variables.
- Removed only visible personal-name copy from the referenced public signup surface.

# RISKS / OPEN QUESTIONS
- `mailto:founding@opb.poker` still needs mailbox confirmation.
- The current public signup remains manual until Supabase production env is configured.

# OUT OF SCOPE
- Supabase setup.
- Stripe checkout setup.
- Broader landing rewrite.
- Git commit/push.

# TEST / VALIDATION
- `npm run build` passed locally.
- `vercel deploy --prod -y` completed successfully.
- `vercel alias set` completed for both `onepercentbetter.poker` and `www.onepercentbetter.poker`.

# RECOMMENDED NEXT STEP
Confirm the live signup page after DNS/cache settles, then replace the `mailto:` target if the founding inbox is different.
